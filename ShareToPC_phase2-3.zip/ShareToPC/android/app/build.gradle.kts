plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.sharetopc.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sharetopc.app"
        minSdk = 24
        targetSdk = 34
        // زد versionCode و versionName مع كل إصدار
        versionCode = 1
        versionName = "0.1.0"
    }

    signingConfigs {
        // مفتاح ثابت داخل المستودع ليتمكن التحديث فوق النسخة المثبتة (للاستخدام الشخصي)
        create("release") {
            storeFile = file("sharetopc.jks")
            storePassword = "sharetopc"
            keyAlias = "sharetopc"
            keyPassword = "sharetopc"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
}
