package com.sharetopc.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.zxing.integration.android.IntentIntegrator

/** شاشة بسيطة: حالة الاقتران + أزرار الاقتران والاختبار. لا شيء يعمل في الخلفية. */
class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var hintView: TextView
    private lateinit var lastView: TextView
    private lateinit var testBtn: Button
    private lateinit var unpairBtn: Button

    private val teal = 0xFF14C9A0.toInt()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(40), dp(24), dp(24))
        }

        val icon = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            layoutParams = LinearLayout.LayoutParams(dp(84), dp(84)).apply { bottomMargin = dp(12) }
        }
        val title = TextView(this).apply {
            text = getString(R.string.app_name)
            setTextColor(Color.WHITE); textSize = 26f; setTypeface(typeface, Typeface.BOLD)
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat(); setColor(0xFF16394A.toInt())
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(20); bottomMargin = dp(20) }
        }
        statusView = TextView(this).apply { setTextColor(Color.WHITE); textSize = 18f; setTypeface(typeface, Typeface.BOLD) }
        hintView = TextView(this).apply { setTextColor(0xFFB6CBD6.toInt()); textSize = 14f; setPadding(0, dp(6), 0, 0) }
        lastView = TextView(this).apply { setTextColor(0xFF7F9AA8.toInt()); textSize = 12f; setPadding(0, dp(10), 0, 0) }
        card.addView(statusView); card.addView(hintView); card.addView(lastView)

        val scanBtn = makeBtn(getString(R.string.btn_scan), true) {
            IntentIntegrator(this).setBeepEnabled(false).setOrientationLocked(false)
                .setPrompt("").initiateScan()
        }
        val pasteBtn = makeBtn(getString(R.string.btn_paste), false) { askCode() }
        testBtn = makeBtn(getString(R.string.btn_test), false) { runTest() }
        unpairBtn = makeBtn(getString(R.string.btn_unpair), false) {
            Store.clear(this); refresh()
        }

        root.addView(icon); root.addView(title); root.addView(card)
        root.addView(scanBtn); root.addView(pasteBtn); root.addView(testBtn); root.addView(unpairBtn)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun makeBtn(label: String, primary: Boolean, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label; isAllCaps = false; textSize = 15f
            setTextColor(if (primary) 0xFF06241C.toInt() else Color.WHITE)
            stateListAnimator = null
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                if (primary) setColor(teal) else { setColor(Color.TRANSPARENT); setStroke(dp(1), 0x8814C9A0.toInt()) }
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
            ).apply { bottomMargin = dp(10) }
            gravity = Gravity.CENTER
            setOnClickListener { onClick() }
        }

    private fun refresh() {
        val p = Store.get(this)
        if (p == null) {
            statusView.text = getString(R.string.status_none)
            hintView.text = getString(R.string.hint_none)
        } else {
            statusView.text = getString(R.string.status_paired, p.name)
            hintView.text = getString(R.string.hint_ready)
        }
        val last = Store.getLast(this)
        lastView.text = if (last != null) getString(R.string.last_op, last) else ""
        testBtn.isEnabled = p != null
        unpairBtn.isEnabled = p != null
        testBtn.alpha = if (p != null) 1f else 0.4f
        unpairBtn.alpha = if (p != null) 1f else 0.4f
    }

    private fun askCode() {
        val input = EditText(this).apply { setSingleLine(false); minLines = 2 }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip?.getItemAt(0)?.text?.toString()
        if (clip != null && clip.startsWith("sharetopc://")) input.setText(clip)
        AlertDialog.Builder(this)
            .setTitle(R.string.dlg_paste_title)
            .setView(input)
            .setPositiveButton(R.string.ok) { _, _ -> handleCode(input.text.toString()) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun handleCode(code: String) {
        val ok = Store.save(this, code)
        Toast.makeText(this, if (ok) R.string.pair_ok else R.string.pair_bad, Toast.LENGTH_SHORT).show()
        refresh()
    }

    private fun runTest() {
        testBtn.isEnabled = false
        val app = applicationContext
        Thread {
            val r = Sender.send(app, "ping", ByteArray(0))
            val ok = r.startsWith("OK")
            val msg = if (ok) app.getString(R.string.test_ok, r.substringAfter(":", "PC"))
                      else Sender.describe(app, r)
            Store.setLast(app, msg)
            runOnUiThread {
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                refresh()
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val r = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (r != null) {
            if (r.contents != null) handleCode(r.contents)
        } else {
            @Suppress("DEPRECATION")
            super.onActivityResult(requestCode, resultCode, data)
        }
    }
}
