package com.sharetopc.app

import android.content.Context
import android.os.Build
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.security.MessageDigest
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLException
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509TrustManager

/**
 * يرسل رسالة واحدة إلى الكمبيوتر عبر TLS مع تثبيت بصمة الشهادة (certificate pinning).
 * البروتوكول: سطر JSON ينتهي بـ \n ثم len بايت، والرد سطر واحد: OK[:اسم] أو ERR:سبب
 * القيم المرجعة: "OK" / "OK:name" / "ERR:xxx" / "unreachable" / "cert"
 */
object Sender {

    private fun pinnedContext(fpHex: String): SSLContext {
        val tm = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {
                val leaf = chain?.firstOrNull() ?: throw CertificateException("no certificate")
                val hex = MessageDigest.getInstance("SHA-256").digest(leaf.encoded)
                    .joinToString("") { "%02X".format(it) }
                if (!hex.equals(fpHex, ignoreCase = true)) throw CertificateException("fingerprint mismatch")
            }
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }
        return SSLContext.getInstance("TLS").apply { init(null, arrayOf(tm), null) }
    }

    /** ينفّذ على خيط خلفي فقط. */
    fun send(ctx: Context, type: String, payload: ByteArray): String {
        val p = Store.get(ctx) ?: return "ERR:not_paired"
        val sslCtx = pinnedContext(p.fp)
        var certProblem = false

        for (host in p.hosts) {
            var sock: SSLSocket? = null
            try {
                sock = sslCtx.socketFactory.createSocket() as SSLSocket
                sock.connect(InetSocketAddress(host, p.port), 2500)
                sock.soTimeout = 15000
                sock.startHandshake()

                val header = JSONObject()
                    .put("v", 1).put("token", p.token).put("type", type)
                    .put("len", payload.size).put("device", Build.MODEL ?: "Android")
                    .toString() + "\n"
                val out = sock.outputStream
                out.write(header.toByteArray(Charsets.UTF_8))
                out.write(payload)
                out.flush()

                val reply = BufferedReader(InputStreamReader(sock.inputStream, Charsets.UTF_8)).readLine()
                    ?: continue
                Store.preferHost(ctx, host)
                return reply.trim()
            } catch (e: SSLException) {
                // تعذّر التحقق من البصمة أو فشل المصافحة
                certProblem = true
            } catch (e: Exception) {
                // هذا العنوان غير متاح، جرّب التالي
            } finally {
                try { sock?.close() } catch (_: Exception) {}
            }
        }
        return if (certProblem) "cert" else "unreachable"
    }

    fun describe(ctx: Context, code: String): String = when {
        code == "unreachable" -> ctx.getString(R.string.err_unreachable)
        code == "cert" -> ctx.getString(R.string.err_cert)
        code == "ERR:auth" -> ctx.getString(R.string.err_auth)
        code == "ERR:paused" -> ctx.getString(R.string.err_paused)
        code == "ERR:no_window" -> ctx.getString(R.string.err_no_window)
        code == "ERR:input_blocked" -> ctx.getString(R.string.err_input_blocked)
        code == "ERR:clipboard" -> ctx.getString(R.string.err_clipboard)
        code == "ERR:not_paired" -> ctx.getString(R.string.toast_not_paired)
        else -> ctx.getString(R.string.err_other, code)
    }
}
