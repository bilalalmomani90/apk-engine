package com.sharetopc.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/**
 * وجهة المشاركة. بلا واجهة: تقرأ النص، ترسله، تعرض Toast، ثم تُغلق.
 * لا توجد خدمة خلفية؛ الاتصال يُفتح لحظة المشاركة فقط.
 */
class ShareReceiverActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Store.get(this) == null) {
            Toast.makeText(this, R.string.toast_not_paired, Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        val text: CharSequence? =
            if (intent?.action == Intent.ACTION_SEND && intent.type?.startsWith("text/") == true)
                intent.getCharSequenceExtra(Intent.EXTRA_TEXT)
            else null

        if (text.isNullOrEmpty()) {
            Toast.makeText(this, R.string.toast_nothing, Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val bytes = text.toString().toByteArray(Charsets.UTF_8)
        val app = applicationContext
        Thread {
            val r = Sender.send(app, "text", bytes)
            val ok = r == "OK" || r.startsWith("OK:")
            Store.setLast(app, if (ok) app.getString(R.string.toast_sent) else Sender.describe(app, r))
            runOnUiThread {
                val msg = if (ok) getString(R.string.toast_sent) else Sender.describe(this, r)
                Toast.makeText(this, msg, if (ok) Toast.LENGTH_SHORT else Toast.LENGTH_LONG).show()
                finish()
            }
        }.start()
    }
}
