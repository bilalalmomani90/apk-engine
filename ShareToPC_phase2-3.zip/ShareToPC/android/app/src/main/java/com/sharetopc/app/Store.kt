package com.sharetopc.app

import android.content.Context
import android.net.Uri
import java.text.DateFormat
import java.util.Date

/** تخزين بيانات الاقتران في مساحة التطبيق الخاصة (allowBackup=false). */
object Store {
    data class Pairing(
        val hosts: List<String>,
        val port: Int,
        val fp: String,
        val token: String,
        val name: String
    )

    private fun sp(c: Context) = c.getSharedPreferences("pairing", Context.MODE_PRIVATE)

    fun get(c: Context): Pairing? {
        val s = sp(c)
        val hosts = s.getString("hosts", null)?.split(",")?.filter { it.isNotBlank() } ?: return null
        val fp = s.getString("fp", null) ?: return null
        val token = s.getString("token", null) ?: return null
        if (hosts.isEmpty()) return null
        return Pairing(hosts, s.getInt("port", 48653), fp, token, s.getString("name", "PC") ?: "PC")
    }

    /** صيغة الرمز: sharetopc://pair?h=ip1,ip2&p=port&fp=SHA256HEX&t=token&n=name */
    fun save(c: Context, code: String): Boolean {
        val u = try { Uri.parse(code.trim()) } catch (e: Exception) { return false }
        if (u.scheme != "sharetopc" || u.host != "pair") return false
        val h = u.getQueryParameter("h") ?: return false
        val p = u.getQueryParameter("p")?.toIntOrNull() ?: return false
        val fp = u.getQueryParameter("fp") ?: return false
        val t = u.getQueryParameter("t") ?: return false
        val n = u.getQueryParameter("n") ?: "PC"
        if (h.isBlank() || p !in 1..65535 || fp.length != 64 || t.length < 16) return false
        sp(c).edit()
            .putString("hosts", h).putInt("port", p)
            .putString("fp", fp.uppercase()).putString("token", t).putString("name", n)
            .apply()
        return true
    }

    fun clear(c: Context) { sp(c).edit().clear().apply() }

    /** يضع آخر عنوان نجح في المقدمة ليُجرَّب أولاً في المرة القادمة. */
    fun preferHost(c: Context, host: String) {
        val p = get(c) ?: return
        val reordered = listOf(host) + p.hosts.filter { it != host }
        sp(c).edit().putString("hosts", reordered.joinToString(",")).apply()
    }

    fun setLast(c: Context, msg: String) {
        val t = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date())
        sp(c).edit().putString("last", "$msg ($t)").apply()
    }

    fun getLast(c: Context): String? = sp(c).getString("last", null)
}
