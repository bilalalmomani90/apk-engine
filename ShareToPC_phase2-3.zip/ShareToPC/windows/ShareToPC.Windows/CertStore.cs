using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace ShareToPC;

/// <summary>شهادة TLS موقّعة ذاتياً تُنشأ مرة واحدة، والهاتف يثبّت بصمتها عند الاقتران.</summary>
static class CertStore
{
    const string Pass = "sharetopc"; // ليست سراً: الحماية الفعلية هي بصمة الشهادة + رمز الاقتران

    public static X509Certificate2 Load()
    {
        var path = Path.Combine(Config.Dir, "cert.pfx");
        if (!File.Exists(path))
        {
            using var rsa = RSA.Create(2048);
            var req = new CertificateRequest("CN=ShareToPC", rsa, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            using var c = req.CreateSelfSigned(DateTimeOffset.UtcNow.AddDays(-1), DateTimeOffset.UtcNow.AddYears(20));
            File.WriteAllBytes(path, c.Export(X509ContentType.Pfx, Pass));
        }
        return new X509Certificate2(path, Pass, X509KeyStorageFlags.Exportable | X509KeyStorageFlags.UserKeySet);
    }

    public static string Fingerprint(X509Certificate2 cert) =>
        Convert.ToHexString(SHA256.HashData(cert.RawData));
}
