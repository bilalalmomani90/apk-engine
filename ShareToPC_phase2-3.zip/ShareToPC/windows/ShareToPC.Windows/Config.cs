using System.Security.Cryptography;
using System.Text.Json;

namespace ShareToPC;

public sealed class ConfigData
{
    public string Token { get; set; } = "";
    public int Port { get; set; } = 48653;
    public bool Paused { get; set; }
    public bool PairShown { get; set; }
}

static class Config
{
    public static readonly string Dir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ShareToPC");
    static string FilePath => Path.Combine(Dir, "config.json");

    public static ConfigData Load()
    {
        Directory.CreateDirectory(Dir);
        ConfigData cfg;
        try
        {
            cfg = File.Exists(FilePath)
                ? JsonSerializer.Deserialize<ConfigData>(File.ReadAllText(FilePath)) ?? new ConfigData()
                : new ConfigData();
        }
        catch { cfg = new ConfigData(); }

        if (string.IsNullOrWhiteSpace(cfg.Token)) { cfg.Token = NewToken(); Save(cfg); }
        return cfg;
    }

    public static void Save(ConfigData cfg)
    {
        Directory.CreateDirectory(Dir);
        File.WriteAllText(FilePath, JsonSerializer.Serialize(cfg));
    }

    public static string NewToken() =>
        Convert.ToBase64String(RandomNumberGenerator.GetBytes(24))
            .Replace('+', '-').Replace('/', '_').TrimEnd('=');
}
