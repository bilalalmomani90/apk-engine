using System.Globalization;

namespace ShareToPC;

/// <summary>ترجمة بسيطة: عربي إذا كانت لغة Windows عربية، وإلا إنجليزي.</summary>
static class L
{
    public static readonly bool Ar = CultureInfo.CurrentUICulture.TwoLetterISOLanguageName == "ar";
    public static string T(string en, string ar) => Ar ? ar : en;
}
