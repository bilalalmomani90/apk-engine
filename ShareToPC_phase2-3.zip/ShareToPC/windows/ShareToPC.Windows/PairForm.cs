using QRCoder;

namespace ShareToPC;

/// <summary>نافذة الاقتران: رمز QR + نص الرمز للنسخ. تظهر عند الطلب فقط.</summary>
sealed class PairForm : Form
{
    readonly ConfigData _cfg;
    readonly string _fp;
    readonly PictureBox _pic = new();
    readonly TextBox _code = new();

    public PairForm(ConfigData cfg, string fingerprint)
    {
        _cfg = cfg; _fp = fingerprint;

        Text = L.T("Pair phone", "اقتران الهاتف");
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false; MinimizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(440, 640);
        RightToLeft = L.Ar ? RightToLeft.Yes : RightToLeft.No;
        RightToLeftLayout = L.Ar;
        using (var s = typeof(PairForm).Assembly.GetManifestResourceStream("app.ico"))
            if (s != null) Icon = new Icon(s);

        var info = new Label
        {
            Text = L.T("Open Share to PC on your phone, tap “Pair with PC”, then scan this code.",
                       "افتح Share to PC على الهاتف، اضغط «اقتران مع الكمبيوتر» ثم امسح هذا الرمز."),
            AutoSize = false, Left = 20, Top = 16, Width = 400, Height = 44
        };

        _pic.Left = 20; _pic.Top = 66; _pic.Width = 400; _pic.Height = 400;
        _pic.SizeMode = PictureBoxSizeMode.Zoom;

        _code.Left = 20; _code.Top = 476; _code.Width = 400; _code.Height = 70;
        _code.Multiline = true; _code.ReadOnly = true; _code.ScrollBars = ScrollBars.Vertical;
        _code.RightToLeft = RightToLeft.No;

        var copy = new Button { Text = L.T("Copy code", "نسخ الرمز"), Left = 20, Top = 556, Width = 190, Height = 34 };
        copy.Click += (_, _) => { try { Clipboard.SetText(_code.Text); } catch { } };

        var reset = new Button { Text = L.T("Reset pairing", "إعادة ضبط الاقتران"), Left = 230, Top = 556, Width = 190, Height = 34 };
        reset.Click += (_, _) =>
        {
            var ok = MessageBox.Show(
                L.T("The paired phone will stop working until you pair again. Continue?",
                    "سيتوقف الهاتف المقترن حتى تعيد الاقتران. هل تريد المتابعة؟"),
                Text, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (ok != DialogResult.Yes) return;
            _cfg.Token = Config.NewToken();
            Config.Save(_cfg);
            Render();
        };

        var warn = new Label
        {
            Text = L.T("Anyone with this code can send text to this PC. Keep it private.",
                       "أي شخص يملك هذا الرمز يستطيع إرسال نص إلى هذا الكمبيوتر. لا تشاركه."),
            AutoSize = false, Left = 20, Top = 598, Width = 400, Height = 32, ForeColor = Color.DimGray
        };

        Controls.AddRange(new Control[] { info, _pic, _code, copy, reset, warn });
        Render();
    }

    public static string BuildCode(ConfigData cfg, string fp)
    {
        var hosts = string.Join(",", Native.LocalIPv4s());
        return $"sharetopc://pair?h={hosts}&p={cfg.Port}&fp={fp}&t={cfg.Token}&n={Uri.EscapeDataString(Environment.MachineName)}";
    }

    void Render()
    {
        var code = BuildCode(_cfg, _fp);
        _code.Text = code;
        using var gen = new QRCodeGenerator();
        using var data = gen.CreateQrCode(code, QRCodeGenerator.ECCLevel.L);
        var png = new PngByteQRCode(data).GetGraphic(8);
        using var ms = new MemoryStream(png);
        using var bmp = new Bitmap(ms);
        var old = _pic.Image;
        _pic.Image = new Bitmap(bmp);
        old?.Dispose();
    }
}
