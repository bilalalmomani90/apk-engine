namespace ShareToPC;

static class Program
{
    [STAThread]
    static void Main()
    {
        using var mutex = new Mutex(true, "ShareToPC.SingleInstance", out bool created);
        if (!created) return;

        ApplicationConfiguration.Initialize();
        Application.Run(new TrayContext());
    }
}
