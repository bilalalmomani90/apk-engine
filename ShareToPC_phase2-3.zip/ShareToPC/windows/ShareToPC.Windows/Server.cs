using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;

namespace ShareToPC;

/// <summary>
/// خادم TLS محلي. البروتوكول: سطر JSON ثم len بايت. الرد سطر واحد.
/// {"v":1,"token":"..","type":"text|ping","len":N,"device":".."}
/// </summary>
sealed class Server
{
    const int MaxText = 2_000_000;

    readonly X509Certificate2 _cert;
    readonly ConfigData _cfg;
    readonly Func<string, byte[], string, Task<string>> _handler;
    TcpListener? _listener;
    CancellationTokenSource? _cts;

    public Server(X509Certificate2 cert, ConfigData cfg, Func<string, byte[], string, Task<string>> handler)
    {
        _cert = cert; _cfg = cfg; _handler = handler;
    }

    public void Start()
    {
        _cts = new CancellationTokenSource();
        _listener = new TcpListener(IPAddress.Any, _cfg.Port);
        _listener.Start();
        var ct = _cts.Token;
        _ = Task.Run(() => AcceptLoop(ct));
    }

    public void Stop()
    {
        try { _cts?.Cancel(); } catch { }
        try { _listener?.Stop(); } catch { }
    }

    async Task AcceptLoop(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try
            {
                var client = await _listener!.AcceptTcpClientAsync(ct);
                _ = Task.Run(() => Handle(client));
            }
            catch (OperationCanceledException) { break; }
            catch (ObjectDisposedException) { break; }
            catch { await Task.Delay(200); }
        }
    }

    async Task Handle(TcpClient client)
    {
        using var _c = client;
        try
        {
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(20));
            var ct = cts.Token;
            using var ssl = new SslStream(client.GetStream(), false);
            await ssl.AuthenticateAsServerAsync(new SslServerAuthenticationOptions
            {
                ServerCertificate = _cert,
                ClientCertificateRequired = false,
                EnabledSslProtocols = SslProtocols.None
            }, ct);

            var line = await ReadLine(ssl, ct);
            if (line == null) return;

            using var doc = JsonDocument.Parse(line);
            var root = doc.RootElement;

            var token = root.TryGetProperty("token", out var t) ? t.GetString() ?? "" : "";
            if (!TokenOk(token)) { await Reply(ssl, "ERR:auth", ct); return; }

            var type = root.TryGetProperty("type", out var ty) ? ty.GetString() ?? "" : "";
            var len = root.TryGetProperty("len", out var l) ? l.GetInt32() : 0;
            var device = root.TryGetProperty("device", out var d) ? d.GetString() ?? "" : "";

            if (len < 0 || len > MaxText) { await Reply(ssl, "ERR:too_large", ct); return; }

            var payload = new byte[len];
            if (len > 0) await ssl.ReadExactlyAsync(payload, ct);

            var result = await _handler(type, payload, device);
            await Reply(ssl, result, ct);
        }
        catch { /* اتصال منقطع أو رسالة غير صالحة: نتجاهلها */ }
    }

    bool TokenOk(string given)
    {
        var a = Encoding.UTF8.GetBytes(given);
        var b = Encoding.UTF8.GetBytes(_cfg.Token);
        return a.Length == b.Length && CryptographicOperations.FixedTimeEquals(a, b);
    }

    static async Task Reply(Stream s, string msg, CancellationToken ct)
    {
        var bytes = Encoding.UTF8.GetBytes(msg + "\n");
        await s.WriteAsync(bytes, ct);
        await s.FlushAsync(ct);
    }

    static async Task<string?> ReadLine(Stream s, CancellationToken ct)
    {
        var buf = new List<byte>(256);
        var one = new byte[1];
        while (buf.Count < 4096)
        {
            int n = await s.ReadAsync(one, ct);
            if (n == 0) return null;
            if (one[0] == (byte)'\n') return Encoding.UTF8.GetString(buf.ToArray());
            buf.Add(one[0]);
        }
        return null;
    }
}
