using System.Security.Cryptography.X509Certificates;
using System.Text;
using Microsoft.Win32;

namespace ShareToPC;

/// <summary>أيقونة System Tray + منطق اللصق. لا توجد نافذة رئيسية.</summary>
sealed class TrayContext : ApplicationContext
{
    const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
    const string RunName = "ShareToPC";

    readonly NotifyIcon _tray;
    readonly Control _ui = new();
    readonly ConfigData _cfg;
    readonly X509Certificate2 _cert;
    readonly string _fp;
    readonly ToolStripMenuItem _status;
    readonly ToolStripMenuItem _pause;
    readonly ToolStripMenuItem _autostart;
    Server? _server;
    PairForm? _pairForm;

    public TrayContext()
    {
        _ = _ui.Handle; // إنشاء المقبض لاستخدام Invoke من خيوط الخلفية

        _cfg = Config.Load();
        _cert = CertStore.Load();
        _fp = CertStore.Fingerprint(_cert);

        var menu = new ContextMenuStrip { RightToLeft = L.Ar ? RightToLeft.Yes : RightToLeft.No };
        _status = new ToolStripMenuItem { Enabled = false };
        _pause = new ToolStripMenuItem(L.T("Pause receiving", "إيقاف الاستقبال مؤقتاً"));
        _pause.Click += (_, _) => { _cfg.Paused = !_cfg.Paused; Config.Save(_cfg); RefreshStatus(); };
        var pair = new ToolStripMenuItem(L.T("Pair phone…", "اقتران الهاتف…"));
        pair.Click += (_, _) => ShowPair();
        _autostart = new ToolStripMenuItem(L.T("Start with Windows", "التشغيل مع Windows")) { CheckOnClick = true };
        _autostart.Checked = IsAutostart();
        _autostart.Click += (_, _) => SetAutostart(_autostart.Checked);
        var exit = new ToolStripMenuItem(L.T("Exit", "خروج"));
        exit.Click += (_, _) => Quit();
        menu.Items.AddRange(new ToolStripItem[] { _status, new ToolStripSeparator(), pair, _pause, _autostart, new ToolStripSeparator(), exit });

        using var iconStream = typeof(TrayContext).Assembly.GetManifestResourceStream("app.ico");
        _tray = new NotifyIcon
        {
            Icon = iconStream != null ? new Icon(iconStream) : SystemIcons.Application,
            Text = "Share to PC",
            ContextMenuStrip = menu,
            Visible = true
        };
        _tray.DoubleClick += (_, _) => ShowPair();

        try
        {
            _server = new Server(_cert, _cfg, OnMessage);
            _server.Start();
        }
        catch (Exception ex)
        {
            Balloon(L.T("Could not start listening", "تعذر بدء الاستقبال"),
                    L.T($"Port {_cfg.Port} may be in use. {ex.Message}", $"قد يكون المنفذ {_cfg.Port} مستخدماً. {ex.Message}"), true);
        }

        RefreshStatus();
        if (!_cfg.PairShown) { _cfg.PairShown = true; Config.Save(_cfg); ShowPair(); }
    }

    void RefreshStatus()
    {
        _status.Text = _cfg.Paused
            ? L.T("Paused", "متوقف مؤقتاً")
            : L.T($"Ready — port {_cfg.Port}", $"جاهز — المنفذ {_cfg.Port}");
        _pause.Text = _cfg.Paused ? L.T("Resume receiving", "استئناف الاستقبال") : L.T("Pause receiving", "إيقاف الاستقبال مؤقتاً");
        _tray.Text = "Share to PC — " + (_cfg.Paused ? L.T("paused", "متوقف") : L.T("ready", "جاهز"));
    }

    void ShowPair()
    {
        if (_pairForm == null || _pairForm.IsDisposed)
        {
            _pairForm = new PairForm(_cfg, _fp);
        }
        _pairForm.Show();
        _pairForm.Activate();
    }

    void Quit()
    {
        _server?.Stop();
        _tray.Visible = false;
        _tray.Dispose();
        ExitThread();
    }

    // ---------- معالجة الرسائل الواردة ----------

    async Task<string> OnMessage(string type, byte[] payload, string device)
    {
        if (_cfg.Paused) return "ERR:paused";

        switch (type)
        {
            case "ping":
                return "OK:" + Environment.MachineName;

            case "text":
                var text = Encoding.UTF8.GetString(payload);
                if (text.Length == 0) return "ERR:empty";
                var r = await PasteTextAsync(text);
                if (r == "OK")
                    Balloon("Share to PC", L.T("Text pasted", "تم لصق النص"), false);
                else
                    Balloon(L.T("Paste failed", "فشل اللصق"), Describe(r), true);
                return r;

            default:
                return "ERR:unsupported"; // الصور: المرحلة الرابعة
        }
    }

    static string Describe(string code) => code switch
    {
        "ERR:no_window" => L.T("No active window.", "لا توجد نافذة نشطة."),
        "ERR:input_blocked" => L.T("Windows blocked pasting (target runs as admin?). The text is on the clipboard.",
                                   "منع Windows اللصق (النافذة تعمل كمسؤول؟). النص موجود في الحافظة."),
        "ERR:clipboard" => L.T("Clipboard was busy.", "الحافظة مشغولة."),
        _ => code
    };

    async Task<string> PasteTextAsync(string text)
    {
        if (Native.GetForegroundWindow() == IntPtr.Zero) return "ERR:no_window";

        text = text.Replace("\r\n", "\n").Replace("\n", "\r\n");
        string? backup = null;

        var err = (string?)_ui.Invoke(new Func<string?>(() =>
        {
            try { if (Clipboard.ContainsText()) backup = Clipboard.GetText(TextDataFormat.UnicodeText); } catch { }
            if (!SetClip(text)) return "ERR:clipboard";
            return Native.SendCtrlV() ? null : "ERR:input_blocked";
        }));

        // عند الفشل نترك النص في الحافظة ليتمكن المستخدم من لصقه يدوياً
        if (err != null) return err;

        await Task.Delay(700); // مهلة ليقرأ التطبيق الهدف الحافظة قبل استعادتها
        if (backup != null)
            _ui.Invoke(new Action(() => { SetClip(backup); }));
        return "OK";
    }

    static bool SetClip(string t)
    {
        if (t.Length == 0) return true;
        for (int i = 0; i < 10; i++)
        {
            try { Clipboard.SetText(t, TextDataFormat.UnicodeText); return true; }
            catch { Thread.Sleep(50); }
        }
        return false;
    }

    void Balloon(string title, string text, bool error)
    {
        _ui.BeginInvoke(new Action(() =>
            _tray.ShowBalloonTip(2000, title, text, error ? ToolTipIcon.Error : ToolTipIcon.Info)));
    }

    // ---------- التشغيل مع Windows ----------

    static bool IsAutostart()
    {
        using var k = Registry.CurrentUser.OpenSubKey(RunKey);
        return k?.GetValue(RunName) != null;
    }

    static void SetAutostart(bool on)
    {
        using var k = Registry.CurrentUser.OpenSubKey(RunKey, true);
        if (k == null) return;
        if (on) k.SetValue(RunName, $"\"{Environment.ProcessPath}\"");
        else k.DeleteValue(RunName, false);
    }
}
