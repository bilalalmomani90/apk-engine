package com.example.javatest;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView t = new TextView(this);
        t.setText("Java test app: build OK");
        t.setTextSize(22f);
        t.setPadding(48, 96, 48, 48);
        setContentView(t);
    }
}
